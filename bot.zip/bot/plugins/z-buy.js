const handler = async ( m ) => {
m.reply(`*_Promo Jadi Bot Hanya 5,000 Saja 1 Bulan 😋_*

Keuntungan ✨
*-* Bebas Add Group Dan Jadi Owner Sekaligus
*-* Bisa Request fitur
*-* Cuman Masukin  Code Saja, Ga Perlu 2 Hp
*-* Bisa Di Jual Kembali Bot Nya
*-* Fresh Respon
*-* Jadi Bot MD No Game Rpg
*-* Jadi Bot RPG Full Fitur
*-* Jadi Bot Store
*-* Jadi Bot Push Kontak
*-* Jadi Bot Bug
*-* Di jamin aman !!

*_TESTIMONI 🛒🛍️_*
https://wa.me/6285939352076
https://wa.me/6285939352076

Minat Atau Mau Tanya Tanya 👤
https://wa.me/6285939352076`)
}
handler.customPrefix = /^(.buy|. buy|. Buy|Buy)$/i;
handler.command = new RegExp();
module.exports = handler